export const marketingImg = [
  { alt: "talabat", src: "/talabat.png", width: 142, height: 40 },
  { alt: "deliveroo", src: "/deliveroo.png", width: 138, height: 77  },
  { alt: "careem", src: "/careem.png", width: 130, height: 26  },
  { alt: "noon-food", src: "/noon-food.png", width: 98, height: 41  },
];

export const contacts = [
  { icon: "/whatsapp.svg", label: "Whatsapp", tel: "+971 58 023 2333", link: "https://wa.me/+971580232333" },
  { label: "Email", tel: "info@chefirinauae.com", link: "mailto:info@chefirinauae.com" },
]
